<div class="menu">
    <div class="lineLeft">
    </div>
    <div class="row">
        <a href="index.php">
        <div class="menuLogo">
        </div>
        </a>
        <div class="menuLink">
            <ul>
                <li><a href="#">Авиабилеты</a></li>
                <li><a href="#">Отели</a></li>
                <li><a href="#">Прокат авто</a></li>
                <li><a href="#">Куда поехать</a></li>
                <li><a href="#">Жилье в аренду</a></li>
                <li><a href="#">Блог</a></li>
            </ul>
        </div>
    </div>
</div>