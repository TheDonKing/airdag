<div class="promo">
    <div class="row">
        <div class="promoBlockMobile">
            <div>
                <img src="img/iphone.png" alt=""/>
            </div>

        </div>
        <div class="promoText">
            <div class="promoTextBoxUp">
                <p>Лучшие цены<br>
                    в вашем сматфоне <br/>
                    или планшете</p>
            </div>
            <div class="promoTextBoxBottom">
                <div class="box1">
                    <p><i class="fa fa-apple"></i><a href="">Iphone</a></p>
                    <p><i class="fa fa-apple"></i><a href="">Ipad</a></p>
                    <p><i class="fa fa-android"></i><a href="">Android</a></p>
                </div>
                <div class="box2">
                    <p><a href="">Подробнее о приложении с поиском авиабилетов и отелей</a></p>
                </div>
            </div>
        </div>
    </div>
</div>