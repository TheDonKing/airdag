<div class="mailResponder">
    <div class="row">
        <div class="box">
            <div>
                <p>Подпишитесь на нашу рассылку</p><span>Получать вдохновение для путешествий, советы и лучшие предложения от DAGAIR:</span>
            </div>
        </div>
        <div class="box">
            <div>
                <form action="#" method="post">
                    <input type="email" placeholder="Введите свой e-mail" name="mailresponder"/>
                    <input type="submit" value="Подписаться"/>
                </form>
            </div>

        </div>
    </div>
</div>