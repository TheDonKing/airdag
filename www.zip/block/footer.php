<div class="footer">
    <div class="row">
        <div class="footerLogo">

        </div>
        <div class="footerLink">
            <a href="">О компании</a>
            <a href="">Вакансии</a>
            <a href="">Условия пользования</a>
            <a href="">Конфиденциальность</a><br/>
            <a href="">Конфиденциальность и Cookies</a>
            <a href="">Авиакомпании</a>
            <a href="">Мобильные приложения</a>
        </div>

    </div>

</div>