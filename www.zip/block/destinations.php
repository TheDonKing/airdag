<div class="destinations">
<div class="destinationsContent">
<div class="destinationsContentTitle">
    <h2>Популярные направления</h2>
</div>
<div class="destinationsContentBlock">
<div class="destinationsContentBlockRow">
<div class="destinationsContentBlockResult">
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/1.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/2.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/3.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.</p>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/4.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.</p>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="destinationsContentBlockResult">
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/5.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.</p>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/6.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.</p>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/7.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.</p>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/1.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="destinationsContentBlockResult">
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/2.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/3.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/4.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/5.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="destinationsContentBlockResult">
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/6.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/7.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/3.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/4.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="destinationsContentBlockResult">
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/5.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/6.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/1.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
    <div class="destinationsContentBlockBox">
        <div class="container">
            <div class="view view-sixth">
                <h3>Стамбул <span>Турция</span></h3>
                <img src="img/view/5.jpg" />
                <div class="mask">
                    <h2>Стамбул</h2>
                    <a href="#" class="info">Подробнее</a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<div class="destinationsContentBlockView">
    <p><a class="view" href="">Подробнее</a></p>
</div>
</div>
</div>