<div class="e_wrapper e_ticket_wrapper">
    <div class="e_ticket_block blue">
        <div class="e_airline_name"><p>Авиакомпания Победа</p></div>
        <div class="e_airticket_title"><p class="from">Махачкала</p> <p class="to">Москва</p> <p class="when">18 апреля</p></div>
        <div class="e_airticket_info">
            <table>
                <tr>
                    <th>Вылет</th>
                    <th>Рейс</th>
                    <th>В пути</th>
                    <th>Прилет</th>
                </tr>
                <tr>
                    <td>Махачкала<br/>Уйташ</td>
                    <td>Авиакомпания Победа DP-188</td>
                    <td>2ч 40 мин</td>
                    <td>Москва<br/>Внуково</td>
                </tr>
                <tr>
                    <td>12:50<br/>18 апреля, Сб</td>
                    <td>Boeing 737-800</td>
                    <td>&nbsp;</td>
                    <td>12:50<br/>18 апреля, Сб </td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>Эконом</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
            </table>
        </div>
        <div class="e_circle"></div>
    </div>
    <div class="e_ticket_block white">
        <div class="e_airline_name"><p>Авиакомпания Победа</p></div>
        <div class="e_airticket_title"><p class="from">Махачкала</p> <p class="to">Москва</p> <p class="when">18 апреля</p></div>
        <div class="e_airticket_info">
            <table>
                <tr>
                    <th>Вылет</th>
                    <th>Рейс</th>
                    <th>В пути</th>
                    <th>Прилет</th>
                </tr>
                <tr>
                    <td>Махачкала<br/>Уйташ</td>
                    <td>Авиакомпания Победа DP-188</td>
                    <td>2ч 40 мин</td>
                    <td>Москва<br/>Внуково</td>
                </tr>
                <tr>
                    <td>12:50 18 апреля, Сб</td>
                    <td>Boeing 737-800</td>
                    <td>&nbsp;</td>
                    <td>12:50 18 апреля, Сб </td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>Эконом</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
            </table>
        </div>
        <div class="e_circle"></div>
    </div>
</div>
<div class="e_wrapper e_form_wrapper">
    <div class="e_form_block">
        <form>
            <table>
                <tr>
                    <td>Пол</td>
                    <td>Фамилия</td>
                    <td>Имя</td>
                    <td>Дата рождения</td>
                </tr>
                <tr>
                    <td>
                        <input checked='true' type="radio" id="Male" name="gender"/><label class="male" for="Male"></label>
                        <input type="radio" id="Female" name="gender"/><label class="female" for="Female"></label>
                    <td>
                        <input type="text" name="surname" placeholder="Магомедов">
                    </td>
                    <td>
                        <input type="text" name="name" placeholder="Магомед">
                    </td>
                    <td>
                        <input type="date" name="date">
                    </td>
                </tr>
                <tr>
                    <td>Гражданство</td>
                    <td>&nbsp;</td>
                    <td>Серия номер док.</td>
                    <td>Срок действия</td>
                </tr>
                <tr>
                    <td>
                        <input type="text" name="" >
                    </td>
                    <td>&nbsp;</td>
                    <td>
                        <input type="text" name="" >
                    </td>
                    <td>
                        <input type="text" name="">
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <div class="e_form_block">
        <form>
            <table>
                <tr>
                    <td>Пол</td>
                    <td>Фамилия</td>
                    <td>Имя</td>
                    <td>Дата рождения</td>
                </tr>
                <tr>
                    <td>
                        <input checked='true' type="radio" id="Male" name="gender"/><label class="male" for="Male"></label>
                        <input type="radio" id="Female" name="gender"/><label class="female" for="Female"></label>
                    <td>
                        <input type="text" name="surname" placeholder="Магомедов">
                    </td>
                    <td>
                        <input type="text" name="name" placeholder="Магомед">
                    </td>
                    <td>
                        <input type="date" name="date">
                    </td>
                </tr>
                <tr>
                    <td>Гражданство</td>
                    <td>&nbsp;</td>
                    <td>Серия номер док.</td>
                    <td>Срок действия</td>
                </tr>
                <tr>
                    <td>
                        <input type="text" name="" >
                    </td>
                    <td>&nbsp;</td>
                    <td>
                        <input type="text" name="" >
                    </td>
                    <td>
                        <input type="text" name="">
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <div class="e_form_block">
        <form>
            <table>
                <tr>
                    <td>Пол</td>
                    <td>Фамилия</td>
                    <td>Имя</td>
                    <td>Дата рождения</td>
                </tr>
                <tr>
                    <td>
                        <input checked='true' type="radio" id="Male" name="gender"/><label class="male" for="Male"></label>
                        <input type="radio" id="Female" name="gender"/><label class="female" for="Female"></label>
                    <td>
                        <input type="text" name="surname" placeholder="Магомедов">
                    </td>
                    <td>
                        <input type="text" name="name" placeholder="Магомед">
                    </td>
                    <td>
                        <input type="date" name="date">
                    </td>
                </tr>
                <tr>
                    <td>Гражданство</td>
                    <td>&nbsp;</td>
                    <td>Серия номер док.</td>
                    <td>Срок действия</td>
                </tr>
                <tr>
                    <td>
                        <input type="text" name="" >
                    </td>
                    <td>&nbsp;</td>
                    <td>
                        <input type="text" name="" >
                    </td>
                    <td>
                        <input type="text" name="">
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <div class="e_form_block">
        <form>
            <table>
                <tr>
                    <td>Пол</td>
                    <td>Фамилия</td>
                    <td>Имя</td>
                    <td>Дата рождения</td>
                </tr>
                <tr>
                    <td>
                        <input checked='true' type="radio" id="Male" name="gender"/><label class="male" for="Male"></label>
                        <input type="radio" id="Female" name="gender"/><label class="female" for="Female"></label>
                    <td>
                        <input type="text" name="surname" placeholder="Магомедов">
                    </td>
                    <td>
                        <input type="text" name="name" placeholder="Магомед">
                    </td>
                    <td>
                        <input type="date" name="date">
                    </td>
                </tr>
                <tr>
                    <td>Гражданство</td>
                    <td>&nbsp;</td>
                    <td>Серия номер док.</td>
                    <td>Срок действия</td>
                </tr>
                <tr>
                    <td>
                        <input type="text" name="" >
                    </td>
                    <td>&nbsp;</td>
                    <td>
                        <input type="text" name="" >
                    </td>
                    <td>
                        <input type="text" name="">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
<div class="e_wrapper">
    <div class="e_insurance">
        <div id="ins_wrap">
            <div id="ins_inner">
                <div id="ins_content">
                    <div id="ins_info">
                        <h2>Страхование на время полета</h2>
                        <p>Получите выплату до&nbsp;10&nbsp;000 рублей при задержке рейса более, чем на&nbsp;4&nbsp;часа.</p>
                        <p>Защитите свой багаж от&nbsp;потери или повреждения на&nbsp;20&nbsp;000 руб.</p>
                        <p>и&nbsp;себя от&nbsp;несчастных случаев на&nbsp;200&nbsp;000 руб.</p><a href="/help/avia/contract-offer-alfa/" class="conditions" target="_blank">полные условия</a></div>
                    <div id="ins_agree">
                        <p>Цена на 1&nbsp;пассажира:</p>
                        <div id="insurance"><span class="price-format"><span class="value">290</span>&nbsp;<span class="currency">руб.</span></span>
                            <label for="insurance_agree" id="insurance_price">
                                <input type="checkbox" id="insurance_agree" name="insurance_agree" autocomplete="off" value="InsuranceProductAviaFlight2"><span class="agree">Добавить в заказ</span></label>
                        </div>
                    </div>
                </div>
                <div id="ins_from" class="ins_point"><span class="flightNo">SU&nbsp;36</span><span class="point">SVO</span></div>
                <div id="ins_to" class="ins_point"><span class="flightNo">SU&nbsp;6573</span><span class="point">KJA</span></div>
            </div>
        </div>

        <div class="trip-cancellation-insurance-wrapper">
            <div class="trip-cancellation-insurance-inner">
                <div class="trip-cancellation-insurance">
                    <div class="trip-cancellation-insurance-header">
                        <h2>Страхование от отмены поездки</h2></div>
                    <ul class="trip-cancellation-insurance-info">
                        <li>Возвращаем до 20 000 руб.</li>
                        <li class="trip-cancellation-insurance-marker">✓ Отказ в визе</li>
                        <li class="trip-cancellation-insurance-marker">✓ Увольнение</li>
                        <li class="trip-cancellation-insurance-marker">✓ ДТП</li>
                        <li class="trip-cancellation-insurance-marker">✓ Катаклизмы</li>
                    </ul>
                    <div class="trip-cancellation-insurance-agree">
                        <p>Цена на 1&nbsp;пассажира:</p>
                        <div id="trip-cancellation-insurance"><span class="price-format"><span class="value">400</span>&nbsp;<span class="currency">руб.</span></span>
                            <label for="trip-cancellation-insurance-agree" id="trip-cancellation-insurance-price">
                                <input type="checkbox" id="trip-cancellation-insurance-agree" name="trip-cancellation-insurance-agree" autocomplete="off"><span class="agree">Добавить в заказ</span></label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="e_payment">
        <div class="e_title">
            <div class="e_price">
                <span>14 137 &#8381;</span>&nbsp;+&nbsp;<span>465 &#8381;</span>&nbsp;+&nbsp;<span>227 &#8381;</span>
            </div>
            <div class="e_all_price">
                <p>= 14 829 &#8381;</p>
            </div>
        </div>
        <div class="e_tab_price" id="horizontalTab">
            <ul class="resp-tabs-list">
                <li>Карта</li>
                <li>Бронь</li>
                <li>Наличными</li>
                <li>Интернет</li>
                <li>PayPal</li>
            </ul>
            <div class="resp-tabs-container">
                <div class="card_tab">
                    <div class="card">
                        <fieldset class="cc-field cc-number">
                            <input type="text" pattern="[0-9]*" size="4" maxlength="4" class="group4" placeholder="XXXX">
                            <input type="text" pattern="[0-9]*" size="4" maxlength="4" class="group4" placeholder="XXXX">
                            <input type="text" pattern="[0-9]*" size="4" maxlength="4" class="group4" placeholder="XXXX">
                            <input type="text" pattern="[0-9]*" size="4" maxlength="4" class="group4" placeholder="XXXX">
                        </fieldset>
                        <fieldset class="cc-field cc-exp">
                            <input type="text" pattern="[0-9]*" placeholder="MM" maxlength="2" class="cc-exp-field-m group2">
                            <input type="text" pattern="[0-9]*" placeholder="YY" maxlength="2" class="cc-exp-field-y group2">
                        </fieldset>
                        <input type="text" placeholder="YOUR NAME" class="cc-name">
                        <input type="text" pattern="[0-9]*" size="3" maxlength="3" class="cvv" placeholder="XXX">
                        <input type="text" placeholder="BANK NAME" class="cc-bank">
                        <select class="currency">
                            <option>RUB</option>
                            <option>USD</option>
                            <option>EUR</option>
                        </select>
                    </div>
                </div>
                <div>
                    <p>2</p>
                </div>
                <div>
                    <p>3</p>
                </div>
                <div>
                    <p>4</p>
                </div>
                <div>
                    <p>5</p>
                </div>
            </div>
        </div>
    </div>
</div>