<div class="select">
    <div class="selectBlock">
        <div class="selectBlockSearch">
            <h2>Выбрать куда поехать</h2>

        </div>
        <div class="selectBlockIcons">
            <div class="selectBlockIconsBlock">
                <div>
                    <div class="hi-icon-wrap hi-icon-effect">
                        <a href="#set-1" class="hi-icon hi-icon-archive"><span>Пляжный отдых</span></a>
                    </div>
                </div>
            </div>
            <div class="selectBlockIconsBlock">
                <div>
                    <div class="hi-icon-wrap hi-icon-effect">
                        <a href="#set-2" class="hi-icon hi-icon-shop"><span>Шопинг</span></a>
                    </div>
                </div>
            </div>
            <div class="selectBlockIconsBlock">
                <div>
                    <div class="hi-icon-wrap hi-icon-effect">
                        <a href="#set-3" class="hi-icon hi-icon-nature"><span>Природа</span></a>
                    </div>
                </div>
            </div>
            <div class="selectBlockIconsBlock">
                <div>
                    <div class="hi-icon-wrap hi-icon-effect">
                        <a href="#set-4" class="hi-icon hi-icon-lifenight"><span>Ночная жизнь</span></a>
                    </div>
                </div>
            </div>
            <div class="selectBlockIconsBlock">
                <div>
                    <div class="hi-icon-wrap hi-icon-effect">
                        <a href="#set-5" class="hi-icon hi-icon-sity"><span>Город</span></a>
                    </div>
                </div>
            </div>
            <div class="selectBlockIconsBlock">
                <div>
                    <div class="hi-icon-wrap hi-icon-effect">
                        <a href="#set-6" class="hi-icon hi-icon-scing"><span>Лыжный спорт</span></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="selectBlockFilter">
            <div class="selectBlockFilterBox">
                <ul>
                    <li><a class="active" href="">Все</a></li>
                    <li><a href="">Где нибудь</a></li>
                    <li><a href="">В любое время</a></li>
                </ul>
            </div>
            <div class="selectBlockFilterBox">
                <ul>
                    <li><span>Мой бюджет:</span></li>
                    <li><a href="">60.000+RUB</a></li>
                </ul>
            </div>
            <div class="selectBlockFilterBox">
                <ul>
                    <li><a class="select-button" href="">Искать</a></li>

                </ul>
            </div>
        </div>
    </div>
</div>